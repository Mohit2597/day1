<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package vodi
 */

$footer_version = vodi_get_footer_version();
get_footer( $footer_version );